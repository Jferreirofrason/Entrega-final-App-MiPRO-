// Pruebas de la bandeja de notificaciones: agrupación por fecha relativa,
// orden por prioridad + fecha descendente y detección de prioritarias.

import test from "node:test";
import assert from "node:assert/strict";
import {
  agruparNotificaciones,
  esPrioritaria,
  grupoDeFecha,
  ordenarNotificaciones,
} from "../src/app/logic/notificaciones.ts";

const HOY = "2026-09-04";

test("el grupo relativo distingue hoy, ayer y anteriores", () => {
  assert.equal(grupoDeFecha("2026-09-04T09:30:00", HOY), "hoy");
  assert.equal(grupoDeFecha("2026-09-03T23:59:00", HOY), "ayer");
  assert.equal(grupoDeFecha("2026-09-02T10:00:00", HOY), "anteriores");
  assert.equal(grupoDeFecha("2026-08-20T10:00:00", HOY), "anteriores");
  // El cruce de mes también resuelve bien el "ayer".
  assert.equal(grupoDeFecha("2026-08-31T10:00:00", "2026-09-01"), "ayer");
});

test("solo el recordatorio de visita próxima es prioritario", () => {
  assert.ok(esPrioritaria({ tipo: "recordatorio", fecha: "2026-09-04T09:00:00" }));
  for (const tipo of ["visita-coordinada", "tecnico-asignado", "cambio-estado", "reclamo", "calificacion", "solicitud-recibida"]) {
    assert.ok(!esPrioritaria({ tipo, fecha: "2026-09-04T09:00:00" }), tipo);
  }
});

test("el orden pone la prioritaria primero y después la más reciente", () => {
  const lista = [
    { id: "vieja", tipo: "cambio-estado", fecha: "2026-09-04T08:00:00" },
    { id: "nueva", tipo: "visita-coordinada", fecha: "2026-09-04T10:00:00" },
    { id: "prioritaria", tipo: "recordatorio", fecha: "2026-09-04T07:00:00" },
  ];
  assert.deepEqual(
    ordenarNotificaciones(lista).map((n) => n.id),
    ["prioritaria", "nueva", "vieja"],
  );
});

test("la agrupación va Hoy → Ayer → Anteriores y omite grupos vacíos", () => {
  const lista = [
    { id: "a", tipo: "cambio-estado", fecha: "2026-09-01T10:00:00" },
    { id: "h", tipo: "recordatorio", fecha: "2026-09-04T09:30:00" },
    { id: "b", tipo: "reclamo", fecha: "2026-08-30T10:00:00" },
  ];
  const grupos = agruparNotificaciones(lista, HOY);
  assert.deepEqual(grupos.map((g) => g.grupo), ["hoy", "anteriores"]);
  assert.deepEqual(grupos[0].items.map((n) => n.id), ["h"]);
  // Dentro de Anteriores, la más reciente arriba.
  assert.deepEqual(grupos[1].items.map((n) => n.id), ["a", "b"]);
});
