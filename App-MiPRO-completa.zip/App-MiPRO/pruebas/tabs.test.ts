// Pruebas de la sección activa del tab bar: cada pantalla enciende UNA
// sección (o ninguna, para pantallas globales como Notificaciones).

import test from "node:test";
import assert from "node:assert/strict";
import { seccionActiva } from "../src/app/logic/tabs.ts";

test("cada pantalla enciende la sección correcta", () => {
  assert.equal(seccionActiva("/"), "inicio");
  // Catálogo y casos de servicio encienden Servicios.
  assert.equal(seccionActiva("/catalogo"), "servicios");
  assert.equal(seccionActiva("/catalogo/sku-y051-000036"), "servicios");
  assert.equal(seccionActiva("/proyectos"), "servicios");
  assert.equal(seccionActiva("/servicios/fixture-aire-multivisita"), "servicios");
  assert.equal(seccionActiva("/solicitud-enviada"), "servicios");
  // Garantía y reclamos encienden Garantía.
  assert.equal(seccionActiva("/garantia"), "garantia");
  assert.equal(seccionActiva("/reclamos/fixture-reclamo-taller"), "garantia");
  // Cuenta y pantallas de perfil encienden Perfil.
  assert.equal(seccionActiva("/perfil"), "perfil");
  assert.equal(seccionActiva("/configuracion"), "perfil");
  assert.equal(seccionActiva("/productos"), "perfil");
});

test("las pantallas globales no encienden ninguna sección", () => {
  assert.equal(seccionActiva("/notificaciones"), null);
});
