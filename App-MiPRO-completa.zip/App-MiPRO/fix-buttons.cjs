const fs = require('fs');
const path = require('path');

const pagesDir = path.join(__dirname, 'src/app/pages');

const files = [
  'Sugerencias.tsx',
  'ProyectoDetalle.tsx',
  'HistorialServicios.tsx',
  'Signup.tsx',
  'Login.tsx',
  'NotFound.tsx',
  'ForgotPassword.tsx',
  'Soporte.tsx',
  'Notificaciones.tsx',
  'ReclamoGarantia.tsx',
  'HistorialServicioDetalle.tsx',
  'Configuracion.tsx',
  'ProductoDetalle.tsx',
  'ProyectosList.tsx',
  'AgendarCita.tsx'
];

const standardButton = `<button
          onClick={() => navigate(-1)}
          className="w-10 h-10 rounded-full flex items-center justify-center transition-opacity hover:opacity-80 border flex-shrink-0"
          style={{
            backgroundColor: 'var(--primary-white)',
            borderColor: 'var(--gray-20)',
          }}
        >
          <ArrowLeft size={20} strokeWidth={2} color="var(--primary-black)" />
        </button>`;

files.forEach(file => {
  const filePath = path.join(pagesDir, file);
  if (fs.existsSync(filePath)) {
    let content = fs.readFileSync(filePath, 'utf8');
    
    // We need to find the button containing ArrowLeft and replace it.
    // It usually looks like:
    // <button ... > ... <ArrowLeft ... /> ... </button>
    
    // A regex to match the button tag and its contents containing ArrowLeft
    const buttonRegex = /<button[^>]*onClick=\{\(\) => navigate\((?:-1|"\/(?:welcome)?")\)\}[^>]*>[\s\S]*?<ArrowLeft[\s\S]*?<\/button>/g;
    
    // Let's also match cases where onClick is not exactly navigate(-1) but it's a back button
    const buttonRegex2 = /<button[^>]*>[\s\S]*?<ArrowLeft[\s\S]*?<\/button>/g;
    
    let replaced = false;
    content = content.replace(buttonRegex2, (match) => {
      // Only replace if it's a back button (has onClick)
      if (match.includes('onClick')) {
        // Extract the onClick handler to preserve it
        const onClickMatch = match.match(/onClick=\{([^}]+)\}/);
        const onClick = onClickMatch ? onClickMatch[0] : 'onClick={() => navigate(-1)}';
        
        replaced = true;
        return `<button
          ${onClick}
          className="w-10 h-10 rounded-full flex items-center justify-center transition-opacity hover:opacity-80 border flex-shrink-0"
          style={{
            backgroundColor: 'var(--primary-white)',
            borderColor: 'var(--gray-20)',
          }}
        >
          <ArrowLeft size={20} strokeWidth={2} color="var(--primary-black)" />
        </button>`;
      }
      return match;
    });

    if (replaced) {
      fs.writeFileSync(filePath, content, 'utf8');
      console.log(`Updated ${file}`);
    } else {
      console.log(`No match in ${file}`);
    }
  }
});
