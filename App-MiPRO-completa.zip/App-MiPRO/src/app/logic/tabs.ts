// Sección activa del tab bar (módulo puro, node --test).
//
// La sección se calcula por PANTALLA, no solo por la ruta del tab: el
// detalle de un servicio o visita enciende Servicios, un reclamo enciende
// Garantía y las pantallas de cuenta encienden Perfil. Notificaciones es
// una pantalla global (sin tab bar): devuelve null, nunca hay dos activos.

export type SeccionTab = "inicio" | "servicios" | "garantia" | "perfil";

export function seccionActiva(pathname: string): SeccionTab | null {
  if (pathname === "/") return "inicio";
  if (/^\/(catalogo|servicios|proyectos|solicitud-enviada)/.test(pathname)) {
    return "servicios";
  }
  if (/^\/(garantia|reclamos)/.test(pathname)) return "garantia";
  if (/^\/(perfil|configuracion|productos|soporte|sugerencias)/.test(pathname)) {
    return "perfil";
  }
  return null;
}
