// Presentación de fecha y hora de una cita en formato fácil de reconocer.
//
// Preferido: "Jueves 12 de marzo, 2:30 p. m." (día de la semana y mes con
// nombre, hora en el formato que ya usa la app). Se formatea desde la fecha
// ISO de la visita; si no está disponible o es inválida, se conservan los
// textos del modelo tal cual. Sin lenguaje relativo ("hoy", "mañana") porque
// puede quedar desactualizado sin recalcularse. Módulo puro (node --test).

function capitalizar(texto: string): string {
  return texto.charAt(0).toUpperCase() + texto.slice(1);
}

export function formatearFechaHora(
  visitAtIso: string | undefined,
  fallbackFecha: string,
  fallbackHora: string,
): string {
  if (visitAtIso) {
    const fecha = new Date(visitAtIso);
    if (!Number.isNaN(fecha.getTime())) {
      // Se quita la coma que ICU agrega tras el día de la semana, para la
      // forma preferida: "Martes 10 de septiembre".
      const parteFecha = new Intl.DateTimeFormat("es", {
        weekday: "long",
        day: "numeric",
        month: "long",
      })
        .format(fecha)
        .replace(/^([^\s,]+),/, "$1");
      const parteHora = new Intl.DateTimeFormat("es", {
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      }).format(fecha);
      return `${capitalizar(parteFecha)}, ${parteHora}`;
    }
  }
  return `${fallbackFecha}, ${fallbackHora}`;
}

/** Solo la fecha, sin hora: "18 de marzo" (para cierres y visitas pasadas). */
export function formatearFecha(iso: string | undefined): string | null {
  if (!iso) return null;
  const fecha = new Date(iso);
  if (Number.isNaN(fecha.getTime())) return null;
  return new Intl.DateTimeFormat("es", { day: "numeric", month: "long" }).format(fecha);
}

/**
 * Fecha con rango horario: "Miércoles 12 de marzo, 2:00 p. m. a 4:00 p. m.".
 * Si falta el fin, cae en formatearFechaHora.
 */
export function formatearFechaRango(
  inicioIso: string | undefined,
  finIso: string | undefined,
): string | null {
  if (!inicioIso) return null;
  const inicio = new Date(inicioIso);
  if (Number.isNaN(inicio.getTime())) return null;
  const base = formatearFechaHora(inicioIso, "", "");
  if (!finIso) return base;
  const fin = new Date(finIso);
  if (Number.isNaN(fin.getTime())) return base;
  const horaFin = new Intl.DateTimeFormat("es", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }).format(fin);
  return `${base} a ${horaFin}`;
}

/**
 * Rango compacto y escaneable: "Miércoles 12 de marzo · 2:00–4:00 p. m.".
 * Cuando inicio y fin comparten meridiano, este se dice una sola vez; si lo
 * cruzan, cada hora lleva el suyo ("11:00 a. m.–1:00 p. m."). Sin fin cae en
 * "Miércoles 12 de marzo · 2:30 p. m.".
 */
export function formatearFechaRangoCompacto(
  inicioIso: string | undefined,
  finIso: string | undefined,
): string | null {
  if (!inicioIso) return null;
  const inicio = new Date(inicioIso);
  if (Number.isNaN(inicio.getTime())) return null;

  const parteFecha = new Intl.DateTimeFormat("es", {
    weekday: "long",
    day: "numeric",
    month: "long",
  })
    .format(inicio)
    .replace(/^([^\s,]+),/, "$1");
  const hora = (d: Date) =>
    new Intl.DateTimeFormat("es", { hour: "numeric", minute: "2-digit", hour12: true }).format(d);

  const horaInicio = hora(inicio);
  const fin = finIso ? new Date(finIso) : null;
  if (!fin || Number.isNaN(fin.getTime())) {
    return `${capitalizar(parteFecha)} · ${horaInicio}`;
  }
  const horaFin = hora(fin);
  const meridiano = (h: string) => (h.includes("a.") ? "am" : h.includes("p.") ? "pm" : "");
  const soloHora = (h: string) => h.replace(/\s*[ap]\.\s*m\.\s*$/i, "").trim();
  const rango =
    meridiano(horaInicio) === meridiano(horaFin) && meridiano(horaInicio) !== ""
      ? `${soloHora(horaInicio)}\u2013${horaFin}`
      : `${horaInicio}\u2013${horaFin}`;
  // El bloque horario viaja entero: si no entra en la línea, baja completo
  // (nunca queda un "p. m." suelto ni se parte en el guion).
  const rangoIndivisible = rango.replace(/ /g, "\u00A0").replace(/\u2013/g, "\u2013\u2060");
  return `${capitalizar(parteFecha)} · ${rangoIndivisible}`;
}

/** Solo la hora: "2:30 p. m." (para visitas que suceden hoy). */
/** Fecha corta para listados compactos: "1 sept". */
export function formatearFechaCorta(iso: string | undefined): string | null {
  if (!iso) return null;
  const fecha = new Date(iso);
  if (Number.isNaN(fecha.getTime())) return null;
  return new Intl.DateTimeFormat("es", { day: "numeric", month: "short" }).format(fecha);
}

export function formatearHora(iso: string | undefined): string | null {
  if (!iso) return null;
  const fecha = new Date(iso);
  if (Number.isNaN(fecha.getTime())) return null;
  return new Intl.DateTimeFormat("es", { hour: "numeric", minute: "2-digit", hour12: true }).format(fecha);
}
