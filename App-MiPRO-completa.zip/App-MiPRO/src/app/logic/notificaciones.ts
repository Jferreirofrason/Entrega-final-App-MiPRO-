// Reglas de la bandeja de notificaciones (módulo puro, node --test).
//
// Principio de producto: cada notificación responde qué cambió, si hay que
// hacer algo y a dónde ir. No todas pesan lo mismo: un recordatorio de
// visita próxima es PRIORITARIO y se destaca; el resto es informativo.
// La bandeja se agrupa por fecha relativa (Hoy / Ayer / Anteriores) y,
// dentro de cada grupo, ordena por prioridad y luego por fecha descendente.

export type GrupoFecha = "hoy" | "ayer" | "anteriores";

export interface NotificacionAgrupable {
  tipo: string;
  /** Fecha ISO con hora. */
  fecha: string;
}

/** Los recordatorios de visita próxima son la prioridad alta del listado. */
export function esPrioritaria(n: NotificacionAgrupable): boolean {
  return n.tipo === "recordatorio";
}

function soloDia(fechaISO: string): string {
  return fechaISO.slice(0, 10);
}

function diaAnterior(diaISO: string): string {
  const d = new Date(`${diaISO}T12:00:00`);
  d.setDate(d.getDate() - 1);
  const mes = String(d.getMonth() + 1).padStart(2, "0");
  const dia = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${mes}-${dia}`;
}

/** Grupo relativo de una fecha respecto de `hoy` (ambas ISO). */
export function grupoDeFecha(fechaISO: string, hoyISO: string): GrupoFecha {
  const dia = soloDia(fechaISO);
  const hoy = soloDia(hoyISO);
  if (dia === hoy) return "hoy";
  if (dia === diaAnterior(hoy)) return "ayer";
  return "anteriores";
}

/** Prioritarias primero; a igual prioridad, la más reciente arriba. */
export function ordenarNotificaciones<T extends NotificacionAgrupable>(
  notificaciones: readonly T[],
): T[] {
  return [...notificaciones].sort((a, b) => {
    const pa = esPrioritaria(a) ? 0 : 1;
    const pb = esPrioritaria(b) ? 0 : 1;
    if (pa !== pb) return pa - pb;
    return b.fecha.localeCompare(a.fecha);
  });
}

/**
 * Agrupa por fecha relativa en el orden Hoy → Ayer → Anteriores, omitiendo
 * los grupos vacíos. Cada grupo llega ya ordenado.
 */
export function agruparNotificaciones<T extends NotificacionAgrupable>(
  notificaciones: readonly T[],
  hoyISO: string,
): { grupo: GrupoFecha; items: T[] }[] {
  const orden: GrupoFecha[] = ["hoy", "ayer", "anteriores"];
  return orden
    .map((grupo) => ({
      grupo,
      items: ordenarNotificaciones(
        notificaciones.filter((n) => grupoDeFecha(n.fecha, hoyISO) === grupo),
      ),
    }))
    .filter((g) => g.items.length > 0);
}
