import { useRef } from "react";
import { CalendarDays, ChevronRight, Wrench, LucideIcon } from "lucide-react";
import {
  ServicioCliente,
  clasificarServicio,
  estadoGeneralServicio,
  fechaDeCierre,
  progresoServicio,
  proximaVisita,
} from "../../logic/servicios";
import { presentarEstadoServicio } from "../../i18n/estados";
import {
  formatearFecha,
  formatearFechaRangoCompacto,
  formatearHora,
} from "../../logic/fechas";
import { getStatusConfig } from "../../utils/statusConfig";
import { CATALOGO_SERVICIOS } from "../../data/catalogo";
import { STR } from "../../i18n/strings";

// Card de un SERVICIO en "Mis servicios", con la anatomía del expediente de
// reclamos: header compacto (sello + número de reserva + estado a la
// derecha), nombre, UNA frase contextual por estado, metadatos con ícono y
// el pie "Ver detalle". Estructura única para todos los estados: solo
// cambian el tag, el mensaje y los metadatos. Sin cards internas ni fondos
// anidados; la altura surge del contenido.
//
// Variantes (derivadas del modelo, nunca inventadas): Solicitud recibida,
// En revisión (coordinando), Cita programada, Servicio en curso (ya
// comenzó), Técnico en camino / visita en curso (solo confirmado por el
// estado de la visita), Servicio finalizado y Solicitud cancelada.

function norm(estado: string): string {
  return estado.trim().toLowerCase();
}

function iconoDelServicio(nombre: string): LucideIcon {
  const encontrado = CATALOGO_SERVICIOS.find(
    (s) => s.nombre.toLowerCase() === nombre.trim().toLowerCase(),
  );
  return encontrado?.icono ?? Wrench;
}

export function TarjetaServicio({
  servicio,
  onVerDetalle,
}: {
  servicio: ServicioCliente;
  onVerDetalle: () => void;
}) {
  const procesando = useRef(false);
  const estado = estadoGeneralServicio(servicio);
  const presentacion = presentarEstadoServicio(estado);
  const enCurso = clasificarServicio(servicio) === "en-curso";
  const progreso = progresoServicio(servicio);
  const proxima = enCurso ? proximaVisita(servicio) : null;
  const Icono = iconoDelServicio(servicio.nombre);

  const onTap = () => {
    if (procesando.current) return;
    procesando.current = true;
    onVerDetalle();
    setTimeout(() => {
      procesando.current = false;
    }, 600);
  };

  // ── Variante de la card ──
  // "En progreso" (vocabulario existente) y "En curso" (vocabulario exacto
  // del seguimiento por estados) son la misma situación: la visita está
  // sucediendo ahora.
  const visitaViva = servicio.visitas.find((v) =>
    ["en camino", "en progreso", "en curso"].includes(norm(v.estado)),
  );
  const enCamino = visitaViva && norm(visitaViva.estado) === "en camino";
  const comenzo = progreso.realizadas >= 1 || Boolean(visitaViva);

  let tag: { texto: string; color: string };
  let mensaje: string;
  if (!enCurso) {
    tag =
      estado === "cancelado"
        ? { texto: STR.servicios.tagServicioCancelado, color: getStatusConfig("cancelado").color }
        : { texto: STR.servicios.tagServicioFinalizado, color: getStatusConfig("completado").color };
    mensaje = estado === "cancelado" ? STR.servicios.msjCancelado : STR.servicios.msjFinalizado;
  } else if (enCamino) {
    tag = { texto: STR.servicios.tagTecnicoEnCamino, color: getStatusConfig("en camino").color };
    mensaje = STR.servicios.msjEnCamino;
  } else if (comenzo) {
    tag = { texto: STR.servicios.tagServicioEnCurso, color: getStatusConfig("en progreso").color };
    mensaje = STR.servicios.msjEnCurso;
  } else if (proxima?.visitAt) {
    // Mismo estado que el detalle (estadoGeneralServicio === "visita-agendada"):
    // la etiqueta sale de la misma fuente centralizada, nunca de un texto propio.
    tag = { texto: presentacion.etiqueta, color: getStatusConfig(presentacion.claveVisual).color };
    mensaje = STR.servicios.msjProgramada;
  } else if (estado === "solicitud-recibida") {
    tag = { texto: presentacion.etiqueta, color: getStatusConfig(presentacion.claveVisual).color };
    mensaje = STR.servicios.msjRecibida;
  } else {
    // Coordinando (o un estado que aún se procesa): sin jerga técnica.
    tag = { texto: presentacion.etiqueta, color: getStatusConfig(presentacion.claveVisual).color };
    mensaje = STR.servicios.msjCoordinando;
  }

  // Avance: solo con 2+ visitas realizadas aporta información.
  const textoProgreso =
    enCurso && progreso.realizadas >= 2
      ? progreso.totalConocido
        ? progreso.realizadas === progreso.total
          ? STR.servicios.progresoCompleto
          : STR.servicios.progresoConocido(progreso.realizadas, progreso.total)
        : STR.servicios.progresoAbierto(progreso.realizadas)
      : null;

  const cierre = !enCurso ? formatearFecha(fechaDeCierre(servicio) ?? undefined) : null;
  const textoCierre = cierre
    ? estado === "cancelado"
      ? STR.servicios.canceladoEl(cierre)
      : STR.servicios.finalizadoEl(cierre)
    : null;
  const creada = formatearFecha(servicio.creadaEl);
  const horaEnCamino = enCamino ? formatearHora(visitaViva?.visitAt) : null;

  const meta = {
    fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif",
  } as const;

  const filaMeta = (IconoFila: LucideIcon | null, contenido: React.ReactNode, margenTop: number) => (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "20px 1fr",
        columnGap: "8px",
        alignItems: "start",
        marginTop: `${margenTop}px`,
      }}
    >
      {IconoFila ? (
        <IconoFila size={16} color="var(--gray-60)" style={{ marginTop: "2px" }} aria-hidden="true" />
      ) : (
        <span aria-hidden="true" />
      )}
      <span style={{ ...meta, fontSize: "14px", lineHeight: "20px", color: "var(--gray-80)" }}>
        {contenido}
      </span>
    </div>
  );

  return (
    <button
      onClick={onTap}
      aria-label={`${servicio.nombre}. ${tag.texto}. ${STR.servicios.verDetalle}.`}
      className="w-full text-left border overflow-hidden transition-all active:scale-[0.99]"
      style={{
        backgroundColor: "var(--card)",
        borderColor: "var(--gray-8)",
        borderRadius: "16px",
        padding: 0,
        boxShadow: "0 1px 2px rgba(0,0,0,0.04)",
        cursor: "pointer",
      }}
    >
      {/* 1. Header compacto: sello + número de reserva | estado */}
      <div
        className="flex items-center justify-between gap-2"
        style={{ backgroundColor: "var(--gray-3)", padding: "8px 16px", minHeight: "40px" }}
      >
        <span className="flex items-center gap-2 flex-shrink-0">
          <span
            aria-hidden="true"
            className="flex items-center justify-center flex-shrink-0"
            style={{ width: "24px", height: "24px", borderRadius: "7px", backgroundColor: "var(--primary-black)" }}
          >
            <Icono size={13} strokeWidth={2.2} color="var(--primary-yellow)" />
          </span>
          {servicio.numeroReserva && (
            <span
              style={{ ...meta, fontSize: "13px", fontWeight: "var(--font-weight-medium)", color: "var(--gray-80)" }}
            >
              {servicio.numeroReserva}
            </span>
          )}
        </span>
        <span className="inline-flex items-center gap-1.5 min-w-0">
          <span
            aria-hidden="true"
            className="inline-block flex-shrink-0"
            style={{ width: "7px", height: "7px", borderRadius: "2px", backgroundColor: tag.color }}
          />
          <span
            className="truncate"
            style={{
              ...meta,
              fontSize: "12px",
              fontWeight: "var(--font-weight-medium)",
              color: tag.color,
              textTransform: "uppercase",
              letterSpacing: "0.5px",
            }}
          >
            {tag.texto}
          </span>
        </span>
      </div>

      <div style={{ padding: "12px 16px 4px" }}>
        {/* 2. Nombre del servicio */}
        <h4
          style={{
            fontFamily: "'Bebas Neue', Arial, sans-serif",
            fontSize: "18px",
            fontWeight: "var(--font-weight-normal)",
            color: "var(--foreground)",
            letterSpacing: "1px",
            textTransform: "uppercase",
            lineHeight: "22px",
            margin: 0,
          }}
        >
          {servicio.nombre}
        </h4>

        {/* 3. Mensaje contextual: una frase clara */}
        <p
          style={{
            ...meta,
            fontSize: "15px",
            lineHeight: "21px",
            color: "var(--gray-80)",
            margin: "6px 0 0",
          }}
        >
          {mensaje}
        </p>

        {/* 4. Metadatos: solo los que existen */}
        {textoProgreso && filaMeta(null, STR.servicios.avanceDe(textoProgreso), 10)}
        {enCamino && horaEnCamino && filaMeta(CalendarDays, STR.servicios.metaVisitaHoy(horaEnCamino), 10)}
        {!enCamino && proxima?.visitAt && (
          comenzo
            ? filaMeta(
                CalendarDays,
                <>
                  {STR.servicios.proximaVisitaLinea(proxima.proposito ?? STR.servicios.visitaGenerica)}{" "}
                  · {formatearFechaRangoCompacto(proxima.visitAt, proxima.visitaFinAt)}
                </>,
                10,
              )
            : filaMeta(CalendarDays, formatearFechaRangoCompacto(proxima.visitAt, proxima.visitaFinAt), 10)
        )}
        {/* El técnico NUNCA aparece en la card del caso: un caso puede tener
            varias visitas con técnicos distintos. Cada técnico se muestra
            dentro de su visita, en el detalle. */}
        {enCurso && !proxima && !enCamino && creada && filaMeta(CalendarDays, STR.servicios.metaCreada(creada), 10)}
        {textoCierre && filaMeta(null, textoCierre, 10)}

        {/* 5. Footer: divisor sutil + Ver detalle */}
        <div
          className="flex items-center justify-end gap-1 mt-3"
          style={{ borderTop: "1px solid var(--gray-8)", minHeight: "44px" }}
        >
          <span
            style={{
              ...meta,
              fontSize: "15px",
              fontWeight: "var(--font-weight-medium)",
              color: "var(--primary-black)",
            }}
          >
            {STR.servicios.verDetalle}
          </span>
          <ChevronRight size={18} strokeWidth={2.5} color="var(--primary-black)" aria-hidden="true" />
        </div>
      </div>
    </button>
  );
}
