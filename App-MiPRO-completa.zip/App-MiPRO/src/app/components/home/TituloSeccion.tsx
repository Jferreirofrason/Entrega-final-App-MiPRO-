import { ReactNode } from "react";

// Encabezado de sección del Home. Es la regla de ritmo vertical de todas las
// secciones: el alto del encabezado es SIEMPRE el mismo, tenga bajada o no,
// tenga acción o no, y el contenido de la sección empieza siempre a la misma
// distancia del arranque de la sección.
//
// Antes cada sección medía distinto y se notaba: "Mis servicios" 44px (la
// fila crecía con el botón "Ver todos"), "Servicios para tu hogar" 50px (fila
// del título más la bajada) y "Promociones" 27px (solo el título). El banner
// negro y las cards horizontales arrancaban a alturas distintas.
//
// La estructura es fija, en tres partes, con auto layout y sin posiciones
// absolutas ni márgenes propios de cada sección:
//
//   fila del título y la acción     ALTO_FILA_TITULO
//   segunda línea: bajada o el espacio reservado    ALTO_SEGUNDA_LINEA
//   gap hasta el contenido          GAP_CONTENIDO
//
// Los tres valores son iguales en mobile y en desktop.

/** Alto de la fila del título. Es el alto de la caja de texto de Bebas 18. */
export const ALTO_FILA_TITULO = 27;

/** Alto de la segunda línea. Se reserva aunque la sección no tenga bajada. */
export const ALTO_SEGUNDA_LINEA = 19;

/** Separación entre la fila del título y la segunda línea. */
export const GAP_SEGUNDA_LINEA = 4;

/** Separación entre el encabezado completo y el contenido de la sección. */
export const GAP_CONTENIDO = 16;

/** Alto total del encabezado, el mismo en todas las secciones. */
export const ALTO_ENCABEZADO =
  ALTO_FILA_TITULO + GAP_SEGUNDA_LINEA + ALTO_SEGUNDA_LINEA;

export function TituloSeccion({
  id,
  children,
  accion,
  bajada,
}: {
  id: string;
  children: ReactNode;
  accion?: ReactNode;
  /** Segunda línea del encabezado. Sin bajada, el espacio queda reservado. */
  bajada?: string;
}) {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: `${GAP_SEGUNDA_LINEA}px`,
        marginBottom: `${GAP_CONTENIDO}px`,
      }}
    >
      {/* Fila de alto fijo: la acción no la estira. El botón "Ver todos" sigue
          midiendo 44px de alto tocable y sobresale de la fila, centrado, sin
          empujar nada: el alto de la fila lo manda esta caja. */}
      <div
        className="flex items-center justify-between"
        style={{ height: `${ALTO_FILA_TITULO}px` }}
      >
        <h3
          id={id}
          style={{
            fontFamily: "'Bebas Neue', Arial, sans-serif",
            fontSize: "18px",
            lineHeight: `${ALTO_FILA_TITULO}px`,
            fontWeight: "var(--font-weight-normal)",
            textTransform: "uppercase",
            letterSpacing: "1px",
            color: "var(--primary-black)",
            margin: 0,
          }}
        >
          {children}
        </h3>
        {accion}
      </div>

      {/* Segunda línea. Con bajada es el párrafo; sin bajada es el mismo alto
          vacío, para que el contenido de todas las secciones arranque igual. */}
      {bajada ? (
        <p
          style={{
            fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif",
            fontSize: "13px",
            lineHeight: `${ALTO_SEGUNDA_LINEA}px`,
            color: "var(--gray-60)",
            margin: 0,
          }}
        >
          {bajada}
        </p>
      ) : (
        <div aria-hidden="true" style={{ height: `${ALTO_SEGUNDA_LINEA}px` }} />
      )}
    </div>
  );
}
