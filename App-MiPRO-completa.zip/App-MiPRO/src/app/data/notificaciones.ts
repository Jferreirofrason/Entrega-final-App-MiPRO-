// Notificaciones del cliente (mock del prototipo).
//
// Siete situaciones reales del ciclo de un servicio y un reclamo, cada una
// con su destino: la fila completa navega al caso, la visita o el reclamo
// correspondiente. "Leída" se recuerda en sessionStorage POR NOTIFICACIÓN:
// abrir una la marca leída (y la campana del Home baja); "Marcar todas como
// leídas" limpia el resto. Las fechas del mock son RELATIVAS al día actual
// para que la bandeja muestre los grupos Hoy / Ayer / Anteriores.

export type TipoNotificacion =
  | "solicitud-recibida"
  | "tecnico-asignado"
  | "visita-coordinada"
  | "cambio-estado"
  | "recordatorio"
  | "reclamo"
  | "calificacion";

export interface NotificacionCliente {
  id: string;
  tipo: TipoNotificacion;
  titulo: string;
  mensaje: string;
  /** Fecha ISO con hora (cuándo llegó). */
  fecha: string;
  /** Servicio al que lleva la fila, cuando aplica. */
  servicioId?: string;
  /** Reclamo de garantía al que lleva la fila, cuando aplica. */
  reclamoId?: string;
}

/** Fecha ISO de hace `dias` días, con la hora dada (mock relativo a hoy). */
function haceDias(dias: number, hora: string): string {
  const d = new Date();
  d.setDate(d.getDate() - dias);
  const mes = String(d.getMonth() + 1).padStart(2, "0");
  const dia = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${mes}-${dia}T${hora}`;
}

const NOTIFICACIONES: NotificacionCliente[] = [
  {
    // PRIORITARIA: recordatorio de visita próxima (el más destacado).
    id: "n-recordatorio",
    tipo: "recordatorio",
    titulo: "Tu visita es mañana",
    mensaje: "La instalación está coordinada para mañana, de 8:00 a. m. a 12:00 p. m.",
    fecha: haceDias(0, "09:30:00"),
    servicioId: "fixture-aire-multivisita",
  },
  {
    id: "n-coordinada",
    tipo: "visita-coordinada",
    titulo: "Visita coordinada",
    mensaje: "Revisa la fecha y el horario de tu próxima visita.",
    fecha: haceDias(0, "08:10:00"),
    servicioId: "fixture-aire-multivisita",
  },
  {
    id: "n-tecnico",
    tipo: "tecnico-asignado",
    titulo: "Técnico asignado",
    mensaje: "Luis Herrera será el técnico de tu próxima visita.",
    fecha: haceDias(1, "16:40:00"),
    servicioId: "fixture-aire-multivisita",
  },
  {
    id: "n-estado",
    tipo: "cambio-estado",
    titulo: "Estamos revisando tu solicitud",
    mensaje: "Te avisaremos cuando la primera visita esté coordinada.",
    fecha: haceDias(3, "11:20:00"),
    servicioId: "fixture-aire-multivisita",
  },
  {
    id: "n-reclamo",
    tipo: "reclamo",
    titulo: "Actualizamos tu reclamo",
    mensaje: "Estamos trabajando en tu solicitud.",
    fecha: haceDias(4, "10:05:00"),
    reclamoId: "fixture-reclamo-taller",
  },
  {
    id: "n-calificacion",
    tipo: "calificacion",
    titulo: "Cuéntanos cómo fue tu servicio",
    mensaje: "Tu visita finalizó. Tu opinión nos ayuda a mejorar.",
    fecha: haceDias(5, "17:30:00"),
    servicioId: "fixture-plomeria-completada",
  },
  {
    id: "n-recibida",
    tipo: "solicitud-recibida",
    titulo: "Recibimos tu solicitud",
    mensaje: "Nos comunicaremos contigo entre 1 y 2 días hábiles para coordinar la visita.",
    fecha: haceDias(6, "09:00:00"),
    servicioId: "fixture-plomeria-completada",
  },
];

const CLAVE_LEIDAS = "mipro-notificaciones-leidas";

function leerIdsLeidas(): Set<string> {
  try {
    const crudo = sessionStorage.getItem(CLAVE_LEIDAS);
    if (crudo) return new Set(JSON.parse(crudo) as string[]);
  } catch {
    // Sin storage: todas se muestran como no leídas.
  }
  return new Set();
}

function guardarIdsLeidas(ids: Set<string>): void {
  try {
    sessionStorage.setItem(CLAVE_LEIDAS, JSON.stringify([...ids]));
  } catch {
    // Sin storage: la campana no baja, nada más.
  }
}

export function listarNotificaciones(): (NotificacionCliente & { leida: boolean })[] {
  const leidas = leerIdsLeidas();
  return NOTIFICACIONES.map((n) => ({ ...n, leida: leidas.has(n.id) }));
}

export function cantidadNoLeidas(): number {
  return listarNotificaciones().filter((n) => !n.leida).length;
}

/** Abrir una notificación la marca leída; el estado persiste al volver. */
export function marcarLeida(id: string): void {
  const leidas = leerIdsLeidas();
  leidas.add(id);
  guardarIdsLeidas(leidas);
}

export function marcarTodasLeidas(): void {
  guardarIdsLeidas(new Set(NOTIFICACIONES.map((n) => n.id)));
}
