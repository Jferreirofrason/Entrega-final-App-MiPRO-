import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router";
import {
  ArrowLeft,
  BellRing,
  CalendarCheck,
  ChevronRight,
  Inbox,
  LucideIcon,
  RefreshCw,
  ShieldCheck,
  Star,
  UserRound,
} from "lucide-react";
import { STR } from "../i18n/strings";
import {
  NotificacionCliente,
  TipoNotificacion,
  listarNotificaciones,
  marcarLeida,
  marcarTodasLeidas,
} from "../data/notificaciones";
import {
  GrupoFecha,
  agruparNotificaciones,
  esPrioritaria,
} from "../logic/notificaciones";
import { formatearFechaCorta, formatearHora } from "../logic/fechas";

// Bandeja de notificaciones: filas compactas de ancho completo, agrupadas
// por fecha relativa (Hoy / Ayer / Anteriores) y ordenadas por prioridad y
// hora. Cada fila responde qué cambió, si hay que hacer algo y a dónde ir:
// la fila COMPLETA navega al caso, la visita o el reclamo. Abrirla la marca
// leída (persiste al volver); "Marcar todas como leídas" aparece solo con
// pendientes.
//
// ── Sobre la forma de esta pantalla ──────────────────────────────────
//
// Es un REGISTRO de lo que fue pasando con tus casos, no un catálogo. Por
// eso se compone como un registro y no como una grilla de tarjetas:
//
// - Sin cajas. Antes cada grupo de fecha era una tarjeta con borde, radio y
//   sombra, todas iguales: la caja no aportaba nada y es justo lo que hace
//   que una pantalla se lea como plantilla. Ahora las filas van a ancho
//   completo separadas por hairlines, y el encabezado de fecha lleva una
//   regla que corre hasta el borde derecho.
// - El encabezado de fecha usa la tipografía de títulos del sistema (Bebas
//   en caja alta), no un "kicker" gris de 12px. Es el idioma que ya habla
//   la app y de paso le da un escalón real a la jerarquía.
// - Cada fila abre con un ícono de LÍNEA según el tipo de novedad. No van
//   encerrados en un círculo a propósito: un círculo con ícono adentro
//   repetido siete veces es decoración, un ícono suelto se escanea.
// - El amarillo se usa UNA vez como gesto: la superficie tenue y la barra
//   al borde son SOLO de la novedad prioritaria. Lo no leído se distingue
//   por el peso del título, el negro del ícono y un punto chico junto a la
//   hora; si cada fila sin leer llevara barra, con la bandeja entera sin
//   leer el acento se repite siete veces y deja de señalar algo.
export function Notificaciones() {
  const navigate = useNavigate();
  const [notificaciones, setNotificaciones] = useState<
    (NotificacionCliente & { leida: boolean })[]
  >(() => listarNotificaciones());
  const procesando = useRef(false);

  const meta = { fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif" } as const;

  const hoy = (() => {
    const d = new Date();
    const mes = String(d.getMonth() + 1).padStart(2, "0");
    const dia = String(d.getDate()).padStart(2, "0");
    return `${d.getFullYear()}-${mes}-${dia}`;
  })();

  const grupos = agruparNotificaciones(notificaciones, hoy);
  const sinLeer = notificaciones.filter((n) => !n.leida).length;

  /** Un ícono por tipo de novedad: la fila se reconoce antes de leerla. */
  const ICONO: Record<TipoNotificacion, LucideIcon> = {
    "solicitud-recibida": Inbox,
    "tecnico-asignado": UserRound,
    "visita-coordinada": CalendarCheck,
    "cambio-estado": RefreshCw,
    recordatorio: BellRing,
    reclamo: ShieldCheck,
    calificacion: Star,
  };

  const destinoDe = (n: NotificacionCliente): string | null => {
    if (n.reclamoId) return `/reclamos/${n.reclamoId}`;
    if (!n.servicioId) return null;
    // La calificación aterriza directo en su módulo dentro del detalle.
    return n.tipo === "calificacion"
      ? `/servicios/${n.servicioId}?calificar=1`
      : `/servicios/${n.servicioId}`;
  };

  // La flecha del detalle vuelve a la bandeja conservando la posición de la
  // lista: se guarda el scroll del contenedor al salir y se restaura al
  // volver. El destino recibe el origen para que su flecha haga history back.
  const raiz = useRef<HTMLDivElement>(null);
  const CLAVE_SCROLL = "mipro-notificaciones-scroll";

  useEffect(() => {
    try {
      const guardado = sessionStorage.getItem(CLAVE_SCROLL);
      if (guardado && raiz.current?.parentElement) {
        raiz.current.parentElement.scrollTop = Number(guardado);
        sessionStorage.removeItem(CLAVE_SCROLL);
      }
    } catch {
      // Sin storage: la lista vuelve arriba, nada más.
    }
  }, []);

  const abrir = (n: NotificacionCliente) => {
    const destino = destinoDe(n);
    if (!destino || procesando.current) return;
    procesando.current = true;
    marcarLeida(n.id);
    setNotificaciones(listarNotificaciones());
    try {
      const scroll = raiz.current?.parentElement?.scrollTop ?? 0;
      sessionStorage.setItem(CLAVE_SCROLL, String(scroll));
    } catch {
      // Sin storage: al volver, la lista arranca arriba.
    }
    navigate(destino, { state: { desdeNotificaciones: true } });
    setTimeout(() => {
      procesando.current = false;
    }, 600);
  };

  const marcarTodas = () => {
    marcarTodasLeidas();
    setNotificaciones(listarNotificaciones());
  };

  const etiquetaGrupo: Record<GrupoFecha, string> = {
    hoy: STR.notificaciones.grupoHoy,
    ayer: STR.notificaciones.grupoAyer,
    anteriores: STR.notificaciones.grupoAnteriores,
  };

  // Hoy y Ayer ya lo dice el grupo: la fila muestra la hora. En Anteriores,
  // fecha corta para que el título nunca se trunque.
  const fechaCorta = (n: NotificacionCliente, grupo: GrupoFecha): string => {
    if (grupo === "anteriores") return formatearFechaCorta(n.fecha) ?? "";
    return formatearHora(n.fecha) ?? "";
  };

  const fila = (
    n: NotificacionCliente & { leida: boolean },
    grupo: GrupoFecha,
    i: number,
  ) => {
    const prioritaria = esPrioritaria(n);
    const Icono = ICONO[n.tipo];
    // Intensidad, de menor a mayor: leída, sin leer, prioritaria. El color
    // del ícono acompaña al peso del título; ninguno de los dos va solo.
    const colorIcono = n.leida ? "var(--gray-40)" : "var(--primary-black)";

    return (
      <button
        key={n.id}
        onClick={() => abrir(n)}
        aria-label={`${n.leida ? "" : `${STR.notificaciones.noLeida}. `}${n.titulo}. ${n.mensaje}`}
        className="w-full text-left transition-colors active:bg-[var(--gray-3)]"
        style={{
          display: "grid",
          gridTemplateColumns: "22px 1fr 16px",
          columnGap: "12px",
          alignItems: "start",
          // El padding izquierdo deja lugar a la barra de no leída sin
          // correr el contenido respecto de las filas ya leídas.
          padding: "14px 24px 14px 24px",
          minHeight: "44px",
          border: "none",
          borderTop: i > 0 ? "1px solid var(--gray-8)" : "none",
          backgroundColor: prioritaria ? "rgba(255, 238, 0, 0.10)" : "transparent",
          boxShadow: prioritaria ? "inset 3px 0 0 var(--primary-yellow)" : undefined,
          cursor: "pointer",
        }}
      >
        {/* Ícono de línea del tipo de novedad, suelto: se escanea la
            columna sin que siete círculos compitan con el texto. */}
        <Icono
          size={20}
          strokeWidth={2.5}
          color={colorIcono}
          style={{ marginTop: "1px" }}
          aria-hidden="true"
        />

        <span className="min-w-0">
          <span className="flex items-baseline gap-2">
            <span
              className="flex-1 min-w-0 line-clamp-2"
              style={{
                ...meta,
                fontSize: "15px",
                lineHeight: "20px",
                fontWeight: n.leida ? "var(--font-weight-normal)" : "var(--font-weight-medium)",
                color: n.leida ? "var(--gray-80)" : "var(--primary-black)",
              }}
            >
              {n.titulo}
            </span>
            <span className="flex items-center gap-1.5 flex-shrink-0">
              {/* Punto de no leída: chico y al lado de la hora, no delante
                  del título, donde se leía como viñeta. */}
              {!n.leida && (
                <span
                  aria-hidden="true"
                  className="inline-block"
                  style={{
                    width: "6px",
                    height: "6px",
                    borderRadius: "2px",
                    backgroundColor: "var(--primary-yellow)",
                    outline: "1px solid var(--gray-40)",
                    outlineOffset: "-1px",
                  }}
                />
              )}
              <span style={{ ...meta, fontSize: "11.5px", color: "var(--gray-40)" }}>
                {fechaCorta(n, grupo)}
              </span>
            </span>
          </span>
          <span
            className="block line-clamp-2"
            style={{
              ...meta,
              fontSize: "13px",
              lineHeight: "19px",
              color: "var(--gray-60)",
              marginTop: "3px",
            }}
          >
            {n.mensaje}
          </span>
        </span>

        <ChevronRight
          size={16}
          strokeWidth={2}
          color="var(--gray-20)"
          style={{ alignSelf: "center" }}
          aria-hidden="true"
        />
      </button>
    );
  };

  return (
    <div ref={raiz} className="flex flex-col" style={{ backgroundColor: "var(--primary-white)" }}>
      <header
        className="flex items-center gap-3 px-6 pt-[20px] pb-4 bg-white sticky top-0 z-20"
        style={{ boxShadow: "0 2px 10px rgba(0,0,0,0.05)" }}
      >
        <button
          onClick={() => navigate(-1)}
          aria-label={STR.notificaciones.volver}
          className="w-11 h-11 rounded-[10px] flex items-center justify-center transition-opacity hover:opacity-80 border flex-shrink-0"
          style={{
            backgroundColor: "var(--primary-white)",
            borderColor: "var(--gray-20)",
            cursor: "pointer",
          }}
        >
          <ArrowLeft size={20} strokeWidth={2} color="var(--primary-black)" aria-hidden="true" />
        </button>
        <h1
          className="truncate flex-1"
          style={{
            fontFamily: "'Bebas Neue', Arial, sans-serif",
            fontSize: "20px",
            fontWeight: "var(--font-weight-normal)",
            letterSpacing: "1px",
            color: "var(--primary-black)",
            margin: 0,
            textTransform: "uppercase",
          }}
        >
          {STR.notificaciones.titulo}
        </h1>
      </header>

      <section className="pb-8">
        {/* La acción va PEGADA al dato que la justifica, en la misma línea:
            suelta arriba a la derecha no se entendía de qué hablaba. */}
        {sinLeer > 0 && (
          <div
            className="flex items-center justify-between gap-3 px-6"
            style={{ paddingTop: "10px", paddingBottom: "10px" }}
          >
            <span style={{ ...meta, fontSize: "13px", color: "var(--gray-60)" }}>
              {STR.notificaciones.sinLeer(sinLeer)}
            </span>
            <button
              onClick={marcarTodas}
              className="transition-opacity hover:opacity-80 flex-shrink-0"
              style={{
                ...meta,
                fontSize: "13px",
                fontWeight: "var(--font-weight-medium)",
                color: "var(--primary-black)",
                background: "none",
                border: "none",
                borderBottom: "1.5px solid var(--primary-yellow)",
                cursor: "pointer",
                minHeight: "44px",
                padding: "0 1px",
              }}
            >
              {STR.notificaciones.marcarTodas}
            </button>
          </div>
        )}

        {notificaciones.length === 0 ? (
          // Vacío tipográfico: el bloque anterior era un cuadrado negro con
          // una campana adentro, que es decoración y no dice nada más que el
          // texto. Una regla y la frase alcanzan.
          <div role="status" className="px-6" style={{ paddingTop: "28px" }}>
            <div style={{ height: "1px", backgroundColor: "var(--gray-8)" }} />
            <p
              style={{
                ...meta,
                fontSize: "16px",
                lineHeight: "22px",
                color: "var(--gray-60)",
                margin: "20px 0 0",
              }}
            >
              {STR.notificaciones.vacioTitulo}
            </p>
          </div>
        ) : (
          <div className="flex flex-col">
            {grupos.map(({ grupo, items }, iGrupo) => (
              <div key={grupo}>
                {/* Encabezado de fecha: tipografía de títulos del sistema y
                    una regla que corre hasta el borde. Marca el corte sin
                    encerrar nada. */}
                <div
                  className="flex items-center gap-3 px-6"
                  style={{ paddingTop: iGrupo === 0 ? "6px" : "26px", paddingBottom: "8px" }}
                >
                  <h2
                    style={{
                      fontFamily: "'Bebas Neue', Arial, sans-serif",
                      fontSize: "16px",
                      fontWeight: "var(--font-weight-normal)",
                      letterSpacing: "1px",
                      textTransform: "uppercase",
                      color: "var(--primary-black)",
                      margin: 0,
                    }}
                  >
                    {etiquetaGrupo[grupo]}
                  </h2>
                  <span
                    aria-hidden="true"
                    className="flex-1"
                    style={{ height: "1px", backgroundColor: "var(--gray-20)" }}
                  />
                </div>
                <div style={{ borderTop: "1px solid var(--gray-8)" }}>
                  {items.map((n, i) => fila(n, grupo, i))}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
