import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router";
import { ArrowLeft, CalendarDays, Info } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Skeleton } from "../components/ui/skeleton";
import { BloqueError } from "../components/home/BloqueError";
import { TarjetaServicio } from "../components/servicios/TarjetaServicio";
import { STR } from "../i18n/strings";
import {
  ServicioCliente,
  clasificarServicio,
  ordenarEnCurso,
  ordenarFinalizadas,
} from "../logic/servicios";
import { cargarServicios, leerEscenarioServicios } from "../data/servicios";
import { irAlCatalogo } from "../lib/navegacion";

type Fase = "cargando" | "error" | "ok";

// "Mis Citas": una card por SERVICIO (no por visita), organizada en dos tabs.
// Las visitas individuales viven en el detalle de cada servicio.
export function ProyectosList() {
  const navigate = useNavigate();
  const location = useLocation();
  const [fase, setFase] = useState<Fase>("cargando");
  const [sinConexion, setSinConexion] = useState(false);
  const [servicios, setServicios] = useState<ServicioCliente[]>([]);
  const [aviso, setAviso] = useState<string | null>(null);
  const [intento, setIntento] = useState(0);

  useEffect(() => {
    let cancelado = false;
    setFase("cargando");
    cargarServicios(leerEscenarioServicios(location.search))
      .then((data) => {
        if (cancelado) return;
        setServicios(data);
        setFase("ok");
      })
      .catch((e: unknown) => {
        if (cancelado) return;
        setSinConexion(e instanceof Error && e.message === "sin-conexion");
        setFase("error");
      });
    return () => {
      cancelado = true;
    };
  }, [location.search, intento]);

  const enCurso = ordenarEnCurso(servicios.filter((s) => clasificarServicio(s) === "en-curso"));
  const finalizadas = ordenarFinalizadas(servicios.filter((s) => clasificarServicio(s) === "finalizadas"));

  const meta = {
    fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif",
  } as const;

  const etiquetaTab = (nombre: string, cantidad: number) =>
    fase === "ok" && cantidad > 0
      ? STR.servicios.tabConCantidad(nombre, cantidad)
      : nombre;

  const skeletons = (
    <div role="status" aria-label={STR.servicios.cargando} aria-busy="true" className="flex flex-col gap-4">
      {[0, 1].map((n) => (
        <div
          key={n}
          className="border"
          style={{
            backgroundColor: "var(--card)",
            borderColor: "var(--gray-8)",
            borderRadius: "16px",
            padding: "20px",
          }}
        >
          <Skeleton className="h-4 w-24" style={{ backgroundColor: "var(--gray-8)" }} />
          <Skeleton className="h-6 w-2/3 mt-2" style={{ backgroundColor: "var(--gray-8)" }} />
          <Skeleton className="h-24 w-full mt-4 rounded-lg" style={{ backgroundColor: "var(--gray-8)" }} />
          <Skeleton className="h-5 w-28 mt-4 ml-auto" style={{ backgroundColor: "var(--gray-8)" }} />
        </div>
      ))}
    </div>
  );

  const vacio = (titulo: string, descripcion: string, conCta: boolean) => (
    <div
      className="flex flex-col items-center gap-3 p-6 text-center border"
      style={{
        backgroundColor: "var(--card)",
        borderColor: "var(--gray-8)",
        borderRadius: "16px",
      }}
    >
      <div
        className="flex items-center justify-center"
        style={{ width: "48px", height: "48px", borderRadius: "12px", backgroundColor: "var(--primary-black)" }}
      >
        <CalendarDays size={24} strokeWidth={2} color="var(--primary-yellow)" aria-hidden="true" />
      </div>
      <p style={{ ...meta, fontSize: "15px", fontWeight: "var(--font-weight-medium)", color: "var(--primary-black)", margin: 0 }}>
        {titulo}
      </p>
      <p style={{ ...meta, fontSize: "14px", lineHeight: "20px", color: "var(--gray-60)", margin: 0 }}>
        {descripcion}
      </p>
      {conCta && (
        <>
          <button
            onClick={() => {
              const navego = irAlCatalogo(navigate);
              if (!navego) setAviso(STR.buscador.catalogoPendiente);
            }}
            className="w-full transition-transform hover:scale-[1.01] active:scale-[0.99] border-none mt-1"
            style={{
              height: "48px",
              backgroundColor: "var(--primary-yellow)",
              borderRadius: "12px",
              ...meta,
              fontSize: "16px",
              fontWeight: "var(--font-weight-medium)",
              color: "var(--primary-black)",
              cursor: "pointer",
            }}
          >
            {STR.servicios.vacioEnCursoAccion}
          </button>
          <div role="status" className="w-full">
            {aviso && (
              <p
                className="flex items-center justify-center gap-1.5"
                style={{ ...meta, fontSize: "12px", color: "var(--gray-60)", margin: 0 }}
              >
                <Info size={14} strokeWidth={2} style={{ flexShrink: 0 }} aria-hidden="true" />
                {aviso}
              </p>
            )}
          </div>
        </>
      )}
    </div>
  );

  const lista = (items: ServicioCliente[]) => (
    <div className="flex flex-col gap-4">
      {items.map((s) => (
        <TarjetaServicio
          key={s.id}
          servicio={s}
          onVerDetalle={() => navigate(`/servicios/${s.id}`)}
        />
      ))}
    </div>
  );

  return (
    <div className="flex flex-col" style={{ backgroundColor: "var(--primary-white)" }}>
      {/* Header */}
      <header
        className="flex items-center gap-3 px-6 pt-[20px] pb-4 bg-white sticky top-0 z-20"
        style={{ boxShadow: "0 2px 10px rgba(0,0,0,0.05)" }}
      >
        <button
          onClick={() => navigate("/")}
          aria-label={STR.servicios.volver}
          className="w-11 h-11 rounded-[10px] flex items-center justify-center transition-opacity hover:opacity-80 border flex-shrink-0"
          style={{
            backgroundColor: "var(--primary-white)",
            borderColor: "var(--gray-20)",
            cursor: "pointer",
          }}
        >
          <ArrowLeft size={20} strokeWidth={2} color="var(--primary-black)" aria-hidden="true" />
        </button>
        <div className="flex-1 min-w-0">
          <h1
            className="truncate"
            style={{
              fontFamily: "'Bebas Neue', Arial, sans-serif",
              fontSize: "20px",
              fontWeight: "var(--font-weight-normal)",
              letterSpacing: "1px",
              color: "var(--primary-black)",
              margin: 0,
              textTransform: "uppercase",
            }}
          >
            {STR.servicios.titulo}
          </h1>
        </div>
      </header>

      <section className="px-6 pt-6 pb-8">
        {fase === "error" ? (
          <BloqueError
            mensaje={sinConexion ? STR.servicios.sinConexion : STR.servicios.error}
            reintentarTexto={STR.servicios.reintentar}
            onReintentar={() => setIntento((n) => n + 1)}
          />
        ) : (
          <Tabs defaultValue="en-curso">
            {/* Control segmentado: el tab activo se distingue por fondo y
                sombra, no solo por color; ambos tabs miden lo mismo. */}
            <TabsList className="w-full mb-4 p-1" style={{ backgroundColor: "var(--gray-3)", height: "48px" }}>
              <TabsTrigger
                value="en-curso"
                className="flex-1"
                style={{ ...meta, fontSize: "14px", fontWeight: "var(--font-weight-medium)", height: "44px" }}
              >
                {etiquetaTab(STR.servicios.tabEnCurso, enCurso.length)}
              </TabsTrigger>
              <TabsTrigger
                value="finalizadas"
                className="flex-1"
                style={{ ...meta, fontSize: "14px", fontWeight: "var(--font-weight-medium)", height: "44px" }}
              >
                {etiquetaTab(STR.servicios.tabFinalizadas, finalizadas.length)}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="en-curso" className="mt-0">
              {fase === "cargando"
                ? skeletons
                : enCurso.length === 0
                  ? vacio(STR.servicios.vacioEnCursoTitulo, STR.servicios.vacioEnCursoDescripcion, true)
                  : lista(enCurso)}
            </TabsContent>

            <TabsContent value="finalizadas" className="mt-0">
              {fase === "cargando"
                ? skeletons
                : finalizadas.length === 0
                  ? vacio(STR.servicios.vacioFinalizadasTitulo, STR.servicios.vacioFinalizadasDescripcion, false)
                  : lista(finalizadas)}
            </TabsContent>
          </Tabs>
        )}
      </section>
    </div>
  );
}
