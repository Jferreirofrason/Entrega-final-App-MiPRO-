import { useParams, useNavigate } from "react-router";
import { ArrowLeft, Calendar, ShieldCheck, ShieldOff, Clock, Plus, ChevronRight, PenTool } from "lucide-react";
import { PRODUCTS_DB } from "../data/products";

export function ProductoDetalle() {
  const { id } = useParams();
  const navigate = useNavigate();

  const product = PRODUCTS_DB[id || '1'] || PRODUCTS_DB['1'];
  const Icon = product.icon;

  const isWarrantyEligible = ["Novey", "Cochez", "Kohler"].includes(product.store);

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      <header 
        className="flex items-center gap-3 px-6 pt-[20px] pb-4 bg-white sticky top-0 z-20"
        style={{
          boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
        }}
      >
        <button
          onClick={() => navigate("/")}
          className="w-11 h-11 rounded-[10px] flex items-center justify-center transition-all hover:scale-105 active:scale-95 border flex-shrink-0"
          style={{
            backgroundColor: 'var(--primary-white)',
            borderColor: 'var(--gray-20)',
            cursor: 'pointer',
            zIndex: 30
          }}
        >
          <ArrowLeft size={20} strokeWidth={2.1} color="var(--primary-black)" />
        </button>
        <div className="flex-1 min-w-0">
          <h1 
            className="truncate"
            style={{
              fontFamily: "'Bebas Neue', Arial, sans-serif",
              fontSize: '20px',
              fontWeight: 'var(--font-weight-normal)',
              letterSpacing: '1px',
              color: 'var(--primary-black)',
              margin: 0,
              textTransform: 'uppercase',
            }}
          >
            {product.name}
          </h1>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        {/* Main Info Card */}
        <section className="px-6 pt-6 pb-6">
          <div className="mb-6 p-5 rounded-2xl" style={{ backgroundColor: 'var(--card)', boxShadow: 'var(--elevation-sm)', border: '1px solid var(--gray-8)' }}>
            <div className="flex items-center gap-4 mb-6">
              <div 
                className="w-16 h-16 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ backgroundColor: 'var(--gray-8)' }}
              >
                <Icon size={32} strokeWidth={1.5} color="var(--primary-black)" />
              </div>
              <div>
                <p
                  style={{
                    fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif",
                    fontSize: '11px',
                    fontWeight: 'var(--font-weight-medium)',
                    color: 'var(--info-blue)',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px',
                    marginBottom: '4px'
                  }}
                >
                  {product.category}
                </p>
                <h2
                  style={{
                    fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif",
                    fontSize: '18px',
                    fontWeight: 'var(--font-weight-medium)',
                    color: 'var(--primary-black)',
                    lineHeight: '1.2',
                    marginBottom: '6px'
                  }}
                >
                  {product.brand}
                </h2>
                <div className="flex items-center gap-2">
                  <span 
                    className="inline-block px-2.5 py-1 rounded-md"
                    style={{ 
                      backgroundColor: 'var(--primary-black)',
                      fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif",
                      fontSize: '11px',
                      fontWeight: 'var(--font-weight-medium)',
                      color: 'var(--primary-white)',
                      letterSpacing: '0.3px'
                    }}
                  >
                    {product.store}
                  </span>
                  {(product.store === "Novey" || product.store === "Cochez") && (
                    <span 
                      style={{ 
                        fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif", 
                        fontSize: '12px', 
                        color: 'var(--gray-60)',
                        fontWeight: 'var(--font-weight-medium)',
                        backgroundColor: 'var(--gray-8)',
                        padding: '2px 8px',
                        borderRadius: '4px'
                      }}
                    >
                      Código de producto: P040-000152
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-4" style={{ borderTop: '1px solid var(--gray-20)' }}>
              <div>
                <p style={{ fontFamily: "'Helvetica Neue LT Std'", fontSize: '11px', color: 'var(--gray-60)', marginBottom: '2px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                  Fecha de compra
                </p>
                <p style={{ fontFamily: "'Helvetica Neue LT Std'", fontSize: '14px', fontWeight: 'var(--font-weight-medium)', color: 'var(--primary-black)' }}>
                  {product.purchaseDate}
                </p>
              </div>
              <div>
                <p style={{ fontFamily: "'Helvetica Neue LT Std'", fontSize: '11px', color: 'var(--gray-60)', marginBottom: '2px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                  Número de Serie
                </p>
                <p style={{ fontFamily: "'Helvetica Neue LT Std'", fontSize: '14px', fontWeight: 'var(--font-weight-medium)', color: 'var(--primary-black)' }}>
                  {product.serialNumber}
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-3 mb-6">
          </div>

          {/* Warranty Section */}
          {isWarrantyEligible && (
            <div 
              className="flex flex-col gap-4 p-5 rounded-2xl mb-6"
              style={{ 
                backgroundColor: 'var(--card)', 
                border: product.hasWarranty ? '1px solid rgba(88, 202, 138, 0.3)' : '1px solid var(--gray-8)', 
                boxShadow: 'var(--elevation-sm)' 
              }}
            >
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl" style={{ backgroundColor: 'var(--gray-8)' }}>
                  <ShieldCheck size={22} strokeWidth={2} color={product.hasWarranty ? "var(--success-green)" : "var(--gray-40)"} />
                </div>
                <div className="flex items-center gap-2">
                  <p style={{ fontFamily: "'Helvetica Neue LT Std'", fontSize: '15px', fontWeight: 'var(--font-weight-medium)', color: 'var(--primary-black)' }}>
                    Garantía
                  </p>
                  {/* Sin garantía, este ícono usa el mismo gris del sistema
                      que el ícono grande de al lado; antes llevaba un gris de
                      otra paleta (#4B5563) y los dos se veían distintos. */}
                  {product.hasWarranty ? (
                    <ShieldCheck size={16} color="var(--success-green)" strokeWidth={2.5} />
                  ) : (
                    <ShieldOff size={16} color="var(--gray-40)" strokeWidth={2.5} />
                  )}
                </div>
              </div>
            </div>
          )}
        </section>
      </div>

      {/* Bottom Fixed Action - Standardized */}
      {isWarrantyEligible && (
        <div 
          className="p-4 bg-white flex-shrink-0 flex items-center justify-center"
          style={{
            boxShadow: '0 10px 30px -5px rgba(0,0,0,0.08)',
            borderTop: '1px solid var(--gray-8)',
            zIndex: 40
          }}
        >
          <button 
            onClick={() => navigate("/garantia/producto")}
            className="w-full h-11 flex items-center justify-center gap-2 transition-transform hover:scale-[1.01] active:scale-[0.99] border-none"
            style={{
              backgroundColor: 'var(--primary-black)',
              boxShadow: '0 10px 30px -5px rgba(0,0,0,0.08)',
              borderRadius: '12px',
              fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif",
              fontSize: '14px',
              fontWeight: 'var(--font-weight-medium)',
              color: 'var(--primary-white)',
              cursor: 'pointer'
            }}
          >
            <ShieldCheck size={20} strokeWidth={2} />
            Gestión de garantía
          </button>
        </div>
      )}
    </div>

  );
}
