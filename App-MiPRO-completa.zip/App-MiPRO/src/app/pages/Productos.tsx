import { useState, useEffect } from "react";
import { Search, Plus, Wind, BedDouble, Refrigerator, Flame, WashingMachine, Fan, ChevronRight, Package, X, ArrowLeft, Check } from "lucide-react";
import { Link, useNavigate, useLocation } from "react-router";
import { PRODUCTS_DB } from "../data/products";

export function Productos() {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeCategory, setActiveCategory] = useState("Todos");
  const [searchQuery, setSearchQuery] = useState("");
  const [extraProducts, setExtraProducts] = useState<any[]>([]);
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    if (location.state?.added) {
      setShowSuccess(true);
      // Clean state so it doesn't show again on refresh
      window.history.replaceState({}, document.title);
      
      const timer = setTimeout(() => {
        setShowSuccess(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [location.state]);

  useEffect(() => {
    const lastAdded = localStorage.getItem("lastAddedProduct");
    if (lastAdded) {
      try {
        const product = JSON.parse(lastAdded);
        // Only show if added in the last 10 minutes to simulate "new"
        if (Date.now() - product.timestamp < 600000) {
          // Map category to icon
          const iconMap: Record<string, any> = {
            "Aire Acondicionado": Wind,
            "Colchón": BedDouble,
            "Refrigeradora": Refrigerator,
            "Calentador": Flame,
            "Lavadora": WashingMachine,
            "Abanico": Fan,
          };
          product.icon = iconMap[product.category] || Package;
          setExtraProducts([product]);
        }
      } catch (e) {
        console.error("Error parsing lastAddedProduct", e);
      }
    }
  }, []);

  const categories = [
    "Todos",
    "Aires acondicionados",
  ];

  const initialProducts = Object.values(PRODUCTS_DB);

  const allProducts = [...extraProducts, ...initialProducts];

  const allowedStores = ["Cochez", "Novey", "Kohler", "Punto Cochez"];

  const filteredProducts = allProducts.filter((product) => {
    const isAllowedStore = allowedStores.includes(product.store);
    if (!isAllowedStore) return false;

    const matchesCategory = activeCategory === "Todos" || product.category === activeCategory || (activeCategory === "Aires acondicionados" && product.category === "Aire Acondicionado");
    const matchesSearch =
      searchQuery === "" ||
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.store.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="flex flex-col min-h-full" style={{ backgroundColor: 'var(--primary-white)' }}>
      {/* Sticky Header + Search + Categories */}
      <div
        style={{
          position: 'sticky',
          top: 0,
          zIndex: 20,
          backgroundColor: '#ffffff',
          boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
        }}
      >
        {/* Header Section */}
        <header
          className="flex items-center gap-3 px-6 pt-[20px] pb-4"
        >
          <button
            onClick={() => navigate("/")}
            className="w-11 h-11 rounded-[10px] flex items-center justify-center transition-all hover:scale-105 active:scale-95 border flex-shrink-0"
            style={{
              backgroundColor: 'var(--primary-white)',
              borderColor: 'var(--gray-20)',
              cursor: 'pointer',
              zIndex: 30
            }}
          >
            <ArrowLeft size={20} strokeWidth={2.1} color="var(--primary-black)" />
          </button>
          <div className="flex-1 min-w-0">
            <h1
              className="truncate"
              style={{
                fontFamily: "'Bebas Neue', Arial, sans-serif",
                fontSize: '20px',
                fontWeight: 'var(--font-weight-normal)',
                letterSpacing: '1px',
                color: 'var(--primary-black)',
                margin: 0,
                textTransform: 'uppercase'
              }}
            >
              Mis productos
            </h1>
          </div>
          <Link
            to="/productos/agregar"
            className="flex items-center gap-2 px-4 py-2 rounded-lg transition-opacity hover:opacity-80"
            style={{
              backgroundColor: 'var(--primary-yellow)',
              border: 'none',
              cursor: 'pointer',
              textDecoration: 'none',
            }}
          >
            <Plus size={18} strokeWidth={2} color="var(--primary-black)" />
            <span
              style={{
                fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif",
                fontSize: '14px',
                fontWeight: 'var(--font-weight-medium)',
                color: 'var(--primary-black)',
              }}
            >
              Agregar
            </span>
          </Link>
        </header>

        {showSuccess && (
          <div 
            className="px-6 py-3 flex items-center justify-between animate-in slide-in-from-top duration-300 stick top-[76px] z-10"
            style={{ backgroundColor: 'rgba(52, 199, 89, 0.1)', borderBottom: '1px solid rgba(52, 199, 89, 0.2)' }}
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-[#34C759] flex items-center justify-center">
                <Check size={14} color="white" strokeWidth={3} />
              </div>
              <p style={{ fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif", fontSize: '13px', fontWeight: 'var(--font-weight-medium)', color: 'var(--primary-black)' }}>
                ¡Producto agregado con éxito!
              </p>
            </div>
            <button onClick={() => setShowSuccess(false)} aria-label="Cerrar aviso" className="p-1" style={{ minWidth: "44px", minHeight: "44px", display: "flex", alignItems: "center", justifyContent: "center", margin: "-12px" }}>
              <X size={16} color="var(--gray-40)" />
            </button>
          </div>
        )}

        {/* Search Bar */}
        <div className="px-6 py-1">
          <div
            className="flex items-center gap-2 w-full transition-all"
            style={{
              height: '40px',
              borderRadius: '10px',
              border: searchQuery ? '1px solid var(--primary-yellow)' : '1px solid var(--gray-8)',
              backgroundColor: 'var(--gray-3)',
              padding: '8px 14px',
            }}
          >
            <Search size={18} strokeWidth={2} color="var(--gray-60)" style={{ flexShrink: 0 }} />
            <input
              type="text"
              placeholder="Buscar mis productos"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 bg-transparent border-none outline-none w-full"
              style={{
                fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif",
                fontSize: '14px',
                color: 'var(--foreground)',
              }}
            />
            {searchQuery.length > 0 && (
              <button
                onClick={() => setSearchQuery('')}
                aria-label="Borrar búsqueda"
                style={{
                  width: '20px', height: '20px', borderRadius: '50%',
                  backgroundColor: 'var(--gray-20)', border: 'none',
                  cursor: 'pointer', display: 'flex', alignItems: 'center',
                  justifyContent: 'center', flexShrink: 0, padding: 0,
                }}
              >
                <X size={12} strokeWidth={2.5} color="var(--gray-80)" />
              </button>
            )}
          </div>
        </div>

        {/* Categories */}
        <div className="px-6 py-3">
          <div className="flex gap-2 overflow-x-auto scrollbar-hide" style={{ scrollbarWidth: 'none' }}>
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                aria-pressed={category === activeCategory}
                className="px-4 py-2 rounded-full whitespace-nowrap transition-colors"
                style={{
                  backgroundColor: category === activeCategory ? 'var(--primary-yellow)' : 'var(--gray-8)',
                  border: 'none',
                  fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif",
                  fontSize: '13px',
                  fontWeight: category === activeCategory ? 'var(--font-weight-medium)' : 'var(--font-weight-normal)',
                  color: category === activeCategory ? 'var(--primary-black)' : 'var(--gray-60)',
                  cursor: 'pointer',
                }}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Products List */}
      <div className="px-6 pt-6 pb-4 flex-1">
        {filteredProducts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12">
            <Search size={40} strokeWidth={1.5} color="var(--gray-20)" />
            <p
              style={{
                fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif",
                fontSize: '14px',
                fontWeight: 'var(--font-weight-normal)',
                color: 'var(--gray-60)',
                textAlign: 'center',
                marginTop: '16px',
              }}
            >
              No se encontraron productos
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {filteredProducts.map((product) => {
              const Icon = product.icon || Package;

              return (
                <Link
                  key={product.id}
                  to={`/productos/${product.id}`}
                  className="rounded-2xl p-5 relative block transition-all hover:scale-[1.02] group"
                  style={{
                    backgroundColor: 'var(--card)',
                    boxShadow: '0 8px 30px rgba(0, 0, 0, 0.04)',
                    border: '1px solid var(--gray-8)',
                    textDecoration: 'none',
                  }}
                >
                  <div className="flex justify-between items-center gap-3">
                    <div className="flex items-center gap-4 flex-1 min-w-0">
                      <div
                        className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors"
                        style={{ backgroundColor: 'var(--gray-8)' }}
                      >
                        <Icon size={26} strokeWidth={1.5} color="var(--primary-black)" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p
                          className="truncate"
                          style={{
                            fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif",
                            fontSize: '11px',
                            fontWeight: 'var(--font-weight-medium)',
                            color: 'var(--info-blue)',
                            marginBottom: '4px',
                            letterSpacing: '0.5px',
                            textTransform: 'uppercase',
                          }}
                        >
                          {product.category}
                        </p>
                        <h4
                          className="leading-tight truncate"
                          style={{
                            fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif",
                            fontSize: '15px',
                            fontWeight: 'var(--font-weight-medium)',
                            color: 'var(--primary-black)',
                            marginBottom: '8px',
                            maxWidth: '100%',
                          }}
                        >
                          {product.name}
                        </h4>
                        <div className="flex items-center gap-2 truncate">
                          <span
                            className="px-2.5 py-1 rounded-md flex-shrink-0"
                            style={{
                              backgroundColor: 'var(--primary-black)',
                              fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif",
                              fontSize: '11px',
                              fontWeight: 'var(--font-weight-medium)',
                              color: 'var(--primary-white)',
                              letterSpacing: '0.3px',
                            }}
                          >
                            {product.brand}
                          </span>
                          <span style={{ color: 'var(--gray-20)', fontSize: '12px' }} className="flex-shrink-0">•</span>
                          <span
                            className="truncate"
                            style={{
                              fontFamily: "'Helvetica Neue LT Std', Arial, sans-serif",
                              fontSize: '13px',
                              fontWeight: 'var(--font-weight-normal)',
                              color: 'var(--gray-60)',
                            }}
                          >
                            {product.store}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 transition-colors group-hover:bg-[var(--primary-yellow)]"
                      style={{ backgroundColor: 'var(--gray-8)' }}
                    >
                      <ChevronRight size={18} strokeWidth={2} color="var(--primary-black)" />
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
