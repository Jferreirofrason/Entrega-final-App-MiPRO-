import { createHashRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { Perfil } from "./pages/Perfil";
import { Notificaciones } from "./pages/Notificaciones";
import { ProyectosList } from "./pages/ProyectosList";
import { NotFound } from "./pages/NotFound";
import { Welcome } from "./pages/Welcome";
import { Login } from "./pages/Login";
import { Signup } from "./pages/Signup";
import { ForgotPassword } from "./pages/ForgotPassword";
import { Configuracion } from "./pages/Configuracion";
import { Soporte } from "./pages/Soporte";
import { Sugerencias } from "./pages/Sugerencias";
import { Productos } from "./pages/Productos";
import { DetalleServicio } from "./pages/DetalleServicio";
import { ListaReclamos } from "./pages/ListaReclamos";
import { DetalleReclamo } from "./pages/DetalleReclamo";
import { CatalogoServicios } from "./pages/CatalogoServicios";
import { GarantiaHub } from "./pages/GarantiaHub";
import { GarantiaProducto } from "./pages/GarantiaProducto";
import { GarantiaProblema } from "./pages/GarantiaProblema";
import { GarantiaRevisar } from "./pages/GarantiaRevisar";
import { GarantiaAgregarDireccion } from "./pages/GarantiaAgregarDireccion";
import { GarantiaConfirmar } from "./pages/GarantiaConfirmar";
import { GarantiaEnviada } from "./pages/GarantiaEnviada";
import { RevisarLugar } from "./pages/RevisarLugar";
import { ConfigurarServicio } from "./pages/ConfigurarServicio";
import { DireccionServicio } from "./pages/DireccionServicio";
import { AgregarDireccion } from "./pages/AgregarDireccion";
import { FechaServicio } from "./pages/FechaServicio";
import { ResumenServicio } from "./pages/ResumenServicio";
import { DetalleCatalogo } from "./pages/DetalleCatalogo";
import { SolicitudEnviada } from "./pages/SolicitudEnviada";
import { ProductoDetalle } from "./pages/ProductoDetalle";
import { AgregarProducto } from "./pages/AgregarProducto";

export const router = createHashRouter([
  // Auth pages (no tab bar)
  { path: "/welcome", Component: Welcome },
  { path: "/login", Component: Login },
  { path: "/signup", Component: Signup },
  { path: "/forgot-password", Component: ForgotPassword },

  // Main app (with tab bar)
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "productos", Component: Productos },
      { path: "productos/agregar", Component: AgregarProducto },
      { path: "productos/:id", Component: ProductoDetalle },
      { path: "perfil", Component: Perfil },
      { path: "notificaciones", Component: Notificaciones },
      { path: "proyectos", Component: ProyectosList },
      { path: "servicios/:id", Component: DetalleServicio },
      { path: "reclamos", Component: ListaReclamos },
      { path: "reclamos/:id", Component: DetalleReclamo },
      { path: "catalogo", Component: CatalogoServicios },
      { path: "catalogo/:id", Component: DetalleCatalogo },
      { path: "catalogo/:id/revisar-lugar", Component: RevisarLugar },
      { path: "catalogo/:id/configurar", Component: ConfigurarServicio },
      { path: "catalogo/:id/direccion", Component: DireccionServicio },
      { path: "catalogo/:id/direccion/nueva", Component: AgregarDireccion },
      { path: "catalogo/:id/fecha", Component: FechaServicio },
      { path: "catalogo/:id/resumen", Component: ResumenServicio },
      { path: "solicitud-enviada", Component: SolicitudEnviada },
      { path: "garantia", Component: GarantiaHub },
      { path: "garantia/producto", Component: GarantiaProducto },
      { path: "garantia/problema", Component: GarantiaProblema },
      { path: "garantia/revisar", Component: GarantiaRevisar },
      { path: "garantia/direccion/nueva", Component: GarantiaAgregarDireccion },
      { path: "garantia/confirmar", Component: GarantiaConfirmar },
      { path: "garantia/enviada", Component: GarantiaEnviada },
      { path: "configuracion", Component: Configuracion },
      { path: "soporte", Component: Soporte },
      { path: "sugerencias", Component: Sugerencias },
      { path: "*", Component: NotFound },
    ],
  },
]);