#!/bin/sh
# Genera el HTML y el PDF del handoff a partir del Markdown.
# El Markdown es la fuente de verdad; esto solo lo publica.
set -e
DIR=$(cd "$(dirname "$0")" && pwd)
CHROME="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"

python3 "$DIR/generar.py"

"$CHROME" --headless --disable-gpu \
  --no-pdf-header-footer \
  --print-to-pdf="$DIR/mipro-design-handoff.pdf" \
  --virtual-time-budget=20000 \
  "file://$DIR/mipro-design-handoff.html" >/dev/null 2>&1

echo "escrito docs/mipro-design-handoff.pdf"
