const { execSync } = require('child_process');
execSync('git checkout src/app/pages');
console.log('Restored');
